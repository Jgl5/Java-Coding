package cryptoproject;

/*Class: CMSC 203 CRN 4666
 * Program: Assignment #3
 * Instructor: Dr.Grinberg
 * Program uses methods to utilize Caesar Cipher and Bellaso Cipher
 * Due: July July 12, 2020
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * Student: Jesus Lopez
 * Compiled on Eclipse IDE
*/
public class CryptoManager {
	
	private static final char LOWER_BOUND = ' ';
	private static final char UPPER_BOUND = '_';
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds 
	 * of ASCII codes according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean stringInBounds (String plainText) {
		//throw new RuntimeException("method not implemented");
		
		// control loop
		for (int index = 0; index < plainText.length(); index++) {
			// checks every character
			if (plainText.charAt(index) >= LOWER_BOUND && plainText.charAt(index) <= UPPER_BOUND) {
				// used for debugging
				//System.out.println("True");
			}
			else {
				return false;
				}
		}
		 return true;
	}
	
	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) {
		//throw new RuntimeException("method not implemented");
		
		// holds the encrypted cipher text
		String holdCipherInformation = "";
		
		// utilizes a control loop
		for(int index =0; index < plainText.length(); index++) {
			
			// holds the value of the characters in the original string
			char originalCharacter = plainText.charAt(index);
			// adds the shift value, based on the entered key amount
			char cipherCharacter=(char) (originalCharacter + key);
				while (cipherCharacter < LOWER_BOUND || cipherCharacter > UPPER_BOUND) {
					cipherCharacter -= RANGE;					
				}
			
			// adds all the cipher characters to the holder string
			// with cipher composed of all the ciphered characters
			holdCipherInformation += cipherCharacter;
		}
				return holdCipherInformation;
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) {
		// throw new RuntimeException("method not implemented");
		
			// holds the cipher with all characters
			String newBellaso = "";
			
					
			// control loop
				for(int index =0; index < plainText.length(); index++) {
					
					// converts and wraps
					char newCharacter = (char) (plainText.charAt(index) 
												+ bellasoStr.charAt(index % bellasoStr.length()));
					
					// keeps my character in bounds
					while (newCharacter < LOWER_BOUND || newCharacter > UPPER_BOUND) {
						newCharacter -= RANGE;					
					}
					// adds all the new characters back together into a string
		       		 newBellaso += newCharacter;
		        }
				return newBellaso;
    }
			
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) {
		//throw new RuntimeException("method not implemented");
		
		String decryptedCaesarText = "";
		
		// control loop
				for(int index =0; index < encryptedText.length(); index++) {
					
					// holds the individual letters
					char holdCipher = encryptedText.charAt(index);
					// removes shift
					char originalCharacter =(char) (holdCipher - key);
					
				//	checks for out of bounds and fixes it
					while (originalCharacter < LOWER_BOUND || originalCharacter > UPPER_BOUND) {
						originalCharacter += RANGE;		
					}
				// adds all de-ciphered characters to holder string
				decryptedCaesarText += (originalCharacter);
				}	
				return  decryptedCaesarText;   
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr) {
		//throw new RuntimeException("method not implemented");
		
		String decipheredText = "";
		
		// control loop
		for(int index =0; index < encryptedText.length(); index++) {
			
			// converts and wraps
			char decryptedCharacter = (char) (encryptedText.charAt(index) 
										- bellasoStr.charAt(index % bellasoStr.length()));
			// keeps my character in bounds
			while (decryptedCharacter < LOWER_BOUND || decryptedCharacter > UPPER_BOUND) {
				decryptedCharacter -= RANGE;					
			}
			
			decipheredText +=decryptedCharacter;
		}
		return decipheredText;
	}
}